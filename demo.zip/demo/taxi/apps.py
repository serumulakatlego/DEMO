from django.apps import AppConfig


class TaxiConfig(AppConfig):
    name = 'taxi'
